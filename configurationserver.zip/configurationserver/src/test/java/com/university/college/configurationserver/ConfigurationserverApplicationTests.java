package com.university.college.configurationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
